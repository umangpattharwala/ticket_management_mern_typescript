export interface IStatus {
  id: string;
  status: string;
  next: string;
  prev: string;
}

export interface ITicket {
  id: Number;
  status: Number;
}
